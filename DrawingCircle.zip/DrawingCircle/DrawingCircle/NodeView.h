//
//  NodeView.h
//  DrawPrj
//
//  Created by lily on 16/11/19.
//  Copyright © 2016年 lily. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NodeView : UIImageView

@property (nonatomic, copy) NSString *number;

@end
